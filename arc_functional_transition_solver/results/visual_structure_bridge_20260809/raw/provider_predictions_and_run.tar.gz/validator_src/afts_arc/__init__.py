"""Minimal validation-time AFTS package snapshot."""
